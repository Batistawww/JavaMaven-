package org.max.home;

/**
 * Общий интерфейс - задача посчитать стоиомость всех элементов
 */
public interface IElement {
    Long sum();
}
