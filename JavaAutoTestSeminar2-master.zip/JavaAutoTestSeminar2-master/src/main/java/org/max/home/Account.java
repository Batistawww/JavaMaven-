package org.max.home;

/**
 * Счет, входит в портфолио имеет стоимость
 */
public record Account(Long sum) implements IElement {

}
