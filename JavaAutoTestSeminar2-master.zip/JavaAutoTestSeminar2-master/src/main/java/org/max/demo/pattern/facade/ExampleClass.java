package org.max.demo.pattern.facade;

/**
 * Класс для демонстрации
 */
public class ExampleClass {

    public int count = 0;

    public void step1() {
        count++;
    }

    public void step2() {
        count++;
    }

    public void step3() {
        count++;
    }

    public void step4() {
        count++;
    }

    public void step5() {
        count++;
    }

    public void step6() {
        count++;
    }
}
