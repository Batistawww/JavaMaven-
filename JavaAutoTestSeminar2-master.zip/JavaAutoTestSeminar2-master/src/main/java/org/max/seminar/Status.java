package org.max.seminar;

/**
 * Вспомогательный Enum
 */
public enum Status {

    OK,
    WARNING,
    ERROR
}
