package org.max.seminar;

/**
 * Ошибка для случая не правильного взаимодейтсвия с интерфейсом подписки
 */
public class NotSubscriptionException extends RuntimeException {
}
